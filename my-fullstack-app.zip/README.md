# My Fullstack Render App

## Run locally
1. Clone repo
2. Start backend:
   ```bash
   cd backend
   npm install
   npm run dev
   ```
3. Start frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```
4. Visit `http://localhost:3000`

## Deploy to Render
1. Push to GitHub
2. In Render dashboard → New → Blueprint → connect repo
3. Render will create:
   - Backend (Node/Express)
   - Frontend (Static React)
   - Postgres database
4. Visit deployed URL 🎉